Austin Tsao and Michelle Wen
README for "prog06_mw37583_ajt2987.zip"

1.  In directory of your choice, run "unzip prog06_mw37583_ajt2987.zip" to unzip files
2. After unzipping, type "make" to compile and link files
3.  Run command "./goFish" to run program.

Rules of Go fish:
1. Only 2 players (both CPU) play this game
2. Player automatically books cards whenever pair is found
3. Game ends when all 26 books are formed (whoever has more books wins)
4. Anytime player's hand is empty, they draw new card from deck
5. Card is never dealt if there are no cards in the deck.
6. Books are when there are 2 cards of equal rank
7. If player asks for card but other player does not have card, 2nd player says go fish
and first player draws new card from deck
8. If player asks for card and other player does have card, 1st player get's 2nd player's
card and first player can ask again. 
